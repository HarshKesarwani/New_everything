package com.amdocs.java.dependencyinjection.injector;

import com.amdocs.java.dependencyinjection.consumer.Consumer;

public interface MessageServiceInjector {

	public Consumer getConsumer();
}
