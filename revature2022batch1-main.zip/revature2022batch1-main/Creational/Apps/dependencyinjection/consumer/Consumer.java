package com.amdocs.java.dependencyinjection.consumer;

public interface Consumer {

	void processMessages(String msg, String rec);
}
