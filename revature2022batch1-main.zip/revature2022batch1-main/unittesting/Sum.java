package com.revature.unittesting;

public class Sum {

	
	public int add(int a,int b) {
		return a+b;
	}
}
