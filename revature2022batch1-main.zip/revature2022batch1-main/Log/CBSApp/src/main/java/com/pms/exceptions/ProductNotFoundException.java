package com.pms.exceptions;

public class ProductNotFoundException extends Exception {
	ProductNotFoundException(String msg) {
		super(msg);
		
	}

}
