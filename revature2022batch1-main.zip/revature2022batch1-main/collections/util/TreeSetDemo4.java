import java.util.*;

public class TreeSetDemo4
{
	public static void main(String args[])
	{
		TreeSet t = new TreeSet();

		t.add(null);
		
		System.out.println(t);
	}
}