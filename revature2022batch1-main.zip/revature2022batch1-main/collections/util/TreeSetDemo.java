import java.util.*;

public class TreeSetDemo
{
	public static void main(String args[])
	{
		TreeSet t = new TreeSet();

		t.add("A");
		t.add("Z");
		t.add("X");
		t.add("C");
		t.add("B");
		
		System.out.println(t);
	}
}