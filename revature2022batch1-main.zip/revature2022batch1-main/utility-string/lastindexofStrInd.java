public class lastindexofStrInd {
	  public static void main(String args[]) {
	  String s = "Java is a wonderful language";
	  System.out.println(s);
	  System.out.println("lastIndexOf(ful, 18) = " + s.lastIndexOf("ful", 18));
	  }
	}