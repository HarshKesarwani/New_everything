public class lastIndexofChar{
	  public static void main(String args[]){
	  String s = "Java is a wonderful language";
	  System.out.println(s);
	  System.out.println("lastIndexOf(a, 19) = " + s.lastIndexOf('a', 19));
	  System.out.println("lastIndexOf(a, 19) = " + s.lastIndexOf(97, 19));
	  }
	}