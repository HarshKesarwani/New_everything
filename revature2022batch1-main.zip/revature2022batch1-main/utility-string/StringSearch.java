public class StringSearch{
		public static void main(String args[]){
		String s = "Bonjour";
		//String begin = 3;
		//String end = 7;
		String t = s.substring(3, 7);   
		System.out.println(t);
		}
	}	