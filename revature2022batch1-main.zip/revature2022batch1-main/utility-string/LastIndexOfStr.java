public class LastIndexOfStr {
  public static void main(String args[]) {
  String s = "public static void main(String args[])";
  System.out.println(s);
  System.out.println("lastIndexOf(void, 10) = " + s.lastIndexOf("void", 10));
  }
}