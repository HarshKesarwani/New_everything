public class StringValue {
	  public static void main(String args[]) {
	  String s = "That was the breaking News";
	  System.out.println(s);
	  System.out.println("indexOf(the) -> " + s.indexOf("break"));
	  }
	}