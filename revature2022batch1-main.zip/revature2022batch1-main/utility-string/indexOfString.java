public class indexOfString {
	  public static void main(String args[]) {
	  String s = "That was the breaking News";
	  System.out.println(s);
	  System.out.println("indexOf(the) -> " + s.indexOf('b'));
	  System.out.println("indexOf(the) -> " + s.indexOf(98));
	  }
	}