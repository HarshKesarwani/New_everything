package com.revature.string;



class Loan{
	
	void show() {
		System.out.println("Loan");
	}
	void getEmi() {
		
	}
}

class EducationLoan extends Loan {
	
}
public class AnnotationsDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
