package pack1;

public class Sum
{
	public int add(int num1,int num2)
	{
		return num1 + num2;
	}
}