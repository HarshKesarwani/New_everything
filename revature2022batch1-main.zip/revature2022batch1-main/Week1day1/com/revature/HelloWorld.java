package com.revature;

import java.util.Date;  //library 

//program with main 

class Person { //3
	
}

class Employee{ //2
	//no main
	
}
public class HelloWorld {//1
	
	
	void show() {
		System.out.println(" show function.....");
	}

	public static void main(String[] args) {
		//sysout ctl+spacebar
		System.out.println("Welcome to Revature FSD training");

		System.out.println(new Date());
		
	}

}
//javac Helloworld.java   - compile java 

//java Helloworld - run the program

