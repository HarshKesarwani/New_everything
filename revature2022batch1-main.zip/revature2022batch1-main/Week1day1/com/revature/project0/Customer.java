package com.revature.project0;

public class Customer {

}
