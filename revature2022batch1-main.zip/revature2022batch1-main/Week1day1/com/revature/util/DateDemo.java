package com.revature.util;

import java.util.Date;
//java.lang   --- system  string exception thread 
//java.util
//java.io    ---
//java.sql  ---
//java.awt   ---window
//java.net.---




public class DateDemo {

	
	
	public Date getDate() {
		return new Date();
	}
}
