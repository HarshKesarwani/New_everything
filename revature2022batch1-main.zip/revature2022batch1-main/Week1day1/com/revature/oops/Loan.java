package com.revature.oops;

public class Loan {
	int loanId;
	String bankName;
	double amount;
	double interestRate;
	Loan() {
		System.out.println("in parent");
	}
	Loan(int id) {
		
	}
	Loan (int id,String name) {
		
	}
	void applyLoan() {
		
	}

	double disburseLoan() {
		return 0.0;
	}
	void calculateEmi() {
		
	}
	void show() {
		
	}
}
