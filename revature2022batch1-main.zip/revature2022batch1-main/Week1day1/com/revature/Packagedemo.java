package com.revature;

import com.revature.util.DateDemo;

//import com.revature.util.DateDemo;

public class Packagedemo {

	public static void main(String[] args) {
		
		DateDemo d=new DateDemo();
		System.out.println(d.getDate());

	}

}
