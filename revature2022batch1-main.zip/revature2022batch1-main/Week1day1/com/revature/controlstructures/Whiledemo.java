package com.revature.controlstructures;

import java.util.Scanner;

public class Whiledemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int x=sc.nextInt();
		int i=1;
		do{ 
			System.out.println(i);
			i++;
		}while(i<=x);
		
		
	}

}
