//Type Conversion Demo
public class TypeConversionDemo
{
    public static void main(String[] args)
    {
		int intNum = 10;
		
		long longNum = intNum;

		System.out.println("Long Num:"+longNum);
		
		double doubleNum = 3.14;

		float floatNum = (float)doubleNum;
		
		System.out.println("Float Num:"+floatNum);
    }
}