class BasicBinaryOperators
{
	public static void main(String args[])
	{
		int x = 9, y = 5;

		System.out.println("\n Out put...");

		System.out.println("		x = " + x );

		System.out.println("		y = " + y );

		System.out.println("		x+y = " + (x+y) );

		System.out.println("		x-y = " + (x-y) );

		System.out.println("		x*y = " + (x*y) );

		System.out.println("		x/y = " + (x/y) );

		System.out.println("		x%y = " + (x%y) );

		// Bitwise Operators
		System.out.println("	\n\n Bitwise Operation ");

		int a = 15, b =16;

		System.out.println("		a&b = " + (a&b) );

		System.out.println("		a|b = " + (a|b) );

		System.out.println("		a^b = " + (a^b) );
	}
}